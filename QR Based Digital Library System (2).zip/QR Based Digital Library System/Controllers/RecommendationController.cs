﻿namespace DigitalLibrarySystem.Controllers;


    using DigitalLibrarySystem.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using  DigitalLibrarySystem.Services;

public class RecommendationController : Controller
{
    private readonly string _connectionString = string.Empty;
    private readonly LoggingService _logger;

    public RecommendationController(IConfiguration configuration, LoggingService logger)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection") ?? string.Empty;
        _logger = logger;
    }

    public IActionResult ForStudent(int studentId)
    {
        var recommendations = new List<object>();

        using SqlConnection con = new SqlConnection(_connectionString);
        string query = @"
            SELECT TOP 5 
                b.BookID, b.Title, b.Author, b.Genre,
                COUNT(*) as PopularityScore
            FROM Books b
            INNER JOIN BorrowingRecords br ON b.BookID = br.BookID
            WHERE b.Genre IN (
                SELECT TOP 3 b2.Genre
                FROM BorrowingRecords br2
                INNER JOIN Books b2 ON br2.BookID = b2.BookID
                WHERE br2.StudentID = @StudentID
                GROUP BY b2.Genre
                ORDER BY COUNT(*) DESC
            )
            AND b.BookID NOT IN (
                SELECT BookID FROM BorrowingRecords WHERE StudentID = @StudentID
            )
            AND b.AvailableCopies > 0
            GROUP BY b.BookID, b.Title, b.Author, b.Genre
            ORDER BY PopularityScore DESC";

        SqlCommand cmd = new SqlCommand(query, con);
        cmd.Parameters.AddWithValue("@StudentID", studentId);
        con.Open();

        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            recommendations.Add(new
            {
                BookID = reader["BookID"],
                Title = reader["Title"],
                Author = reader["Author"],
                Genre = reader["Genre"],
                Score = reader["PopularityScore"]
            });
        }

        _logger.Log(studentId, "RECOMMENDATION", $"Recommendations fetched for student {studentId}");
        return Json(recommendations);
    }
}