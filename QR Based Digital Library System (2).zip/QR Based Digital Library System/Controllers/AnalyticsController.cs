﻿namespace DigitalLibrarySystem.Controllers;


using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

public class AnalyticsController : Controller
{
    private readonly string _connectionString = string.Empty;

    public AnalyticsController(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection") ?? string.Empty;
    }

    public IActionResult MostActiveStudents()
    {
        var data = new List<object>();
        using SqlConnection con = new SqlConnection(_connectionString);
        string query = @"SELECT TOP 10 
            s.StudentID, s.Name, s.Department,
            COUNT(br.RecordID) as TotalBorrows
            FROM Students s
            LEFT JOIN BorrowingRecords br ON s.StudentID = br.StudentID
            GROUP BY s.StudentID, s.Name, s.Department
            ORDER BY TotalBorrows DESC";

        SqlCommand cmd = new SqlCommand(query, con);
        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            data.Add(new
            {
                StudentID = reader["StudentID"],
                Name = reader["Name"],
                Department = reader["Department"],
                TotalBorrows = reader["TotalBorrows"]
            });
        }
        return Json(data);
    }

    public IActionResult PopularBooks()
    {
        var data = new List<object>();
        using SqlConnection con = new SqlConnection(_connectionString);
        string query = @"SELECT TOP 10 
            b.BookID, b.Title, b.Author,
            COUNT(br.RecordID) as BorrowCount
            FROM Books b
            LEFT JOIN BorrowingRecords br ON b.BookID = br.BookID
            GROUP BY b.BookID, b.Title, b.Author
            ORDER BY BorrowCount DESC";

        SqlCommand cmd = new SqlCommand(query, con);
        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            data.Add(new
            {
                BookID = reader["BookID"],
                Title = reader["Title"],
                Author = reader["Author"],
                BorrowCount = reader["BorrowCount"]
            });
        }
        return Json(data);
    }

    public IActionResult FineTrends()
    {
        var data = new List<object>();
        using SqlConnection con = new SqlConnection(_connectionString);
        string query = @"SELECT 
            MONTH(IssueDate) as Month,
            YEAR(IssueDate) as Year,
            SUM(FineAmount) as TotalFines,
            COUNT(*) as FineCount
            FROM BorrowingRecords
            WHERE FineAmount > 0
            GROUP BY YEAR(IssueDate), MONTH(IssueDate)
            ORDER BY Year DESC, Month DESC";

        SqlCommand cmd = new SqlCommand(query, con);
        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            data.Add(new
            {
                Month = reader["Month"],
                Year = reader["Year"],
                TotalFines = reader["TotalFines"],
                FineCount = reader["FineCount"]
            });
        }
        return Json(data);
    }

    public IActionResult DepartmentStats()
    {
        var data = new List<object>();
        using SqlConnection con = new SqlConnection(_connectionString);
        string query = @"SELECT 
            s.Department,
            COUNT(DISTINCT s.StudentID) as TotalStudents,
            COUNT(br.RecordID) as TotalBorrows,
            SUM(ISNULL(br.FineAmount, 0)) as TotalFines
            FROM Students s
            LEFT JOIN BorrowingRecords br ON s.StudentID = br.StudentID
            GROUP BY s.Department
            ORDER BY TotalBorrows DESC";

        SqlCommand cmd = new SqlCommand(query, con);
        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            data.Add(new
            {
                Department = reader["Department"],
                TotalStudents = reader["TotalStudents"],
                TotalBorrows = reader["TotalBorrows"],
                TotalFines = reader["TotalFines"]
            });
        }
        return Json(data);
    }

    public IActionResult Index()
    {
        return View();
    }
}